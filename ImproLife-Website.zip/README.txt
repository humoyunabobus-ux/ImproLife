ImproLife - website version (the same app as the preview, but it is a real website you can host)
=============================================================================================

WHAT IS IN THIS FOLDER
  index.html            the whole app (open this)
  manifest.webmanifest  makes it installable on a phone ("Add to Home screen")
  sw.js                 lets it open offline
  icon.svg, icon-192.png, icon-512.png

1) TEST IT ON YOUR COMPUTER (pick the easiest for you)
   A. Easiest, nothing to install: double-click  index.html  (it opens in your browser). Everything works except "install" and "offline".
   B. With a small local server (only if you have Python installed):
        - open the unzipped folder, click the address bar of the folder, type  cmd  and press Enter (Windows)
        - type   py -m http.server 8080    (or   python -m http.server 8080 )  and press Enter
        - the window shows "Serving HTTP on ... port 8080" and then just STAYS OPEN and looks empty. That is normal: it is running.
        - now open  http://localhost:8080  in Chrome. Close the window to stop it.
      If you get "python is not recognized", use option A or option 2 below (no installation).

2) PUT IT ONLINE FOR FREE (pick one)
   - Netlify Drop:   go to app.netlify.com/drop and drag THIS folder onto the page. You get a link at once.
   - GitHub Pages:   upload these files to a repository, then Settings > Pages > Deploy from branch.
   - Firebase Hosting: npm i -g firebase-tools, firebase login, firebase init hosting (public folder = this one), firebase deploy.
   All of them use https, which a phone needs to install the app.

3) USE IT LIKE AN APP ON YOUR PHONE
   Open the link in Chrome (Android) or Safari (iPhone), then: menu > "Add to Home screen" / "Install app".

WHAT IS REAL AND WHAT IS A DEMO
  Real: all screens, the habit logic, streaks and levels, themes (one or two colours, glass), the colour wheel, nature sounds (generated in the page),
        the photo editor (crop, zoom, rotate, text), the strict bad-word filter, the 50-word bio limit, and the adult-content photo check
        (an AI model that runs in your browser; it needs internet the first time to download the model).
  Demo: the ranking list, friend requests, camera exercise counting, the AI reading check and the AI coach are simulated here.
        In the Android app they use Firebase and Gemini (see the Android project README).
  Your data is saved only in this browser (localStorage). Use Settings > "Demo: start as a new user" to reset.

TESTING THE PHOTO FILTER
  Settings > Profile photo > Choose photo > Save. The first time, wait a few seconds while the model downloads.
  Explicit or suggestive pictures (for example swimwear) are refused with "This photo can't be used."
  If the model cannot download, ANY photo is refused ("Couldn't check the photo") - it never lets an unchecked photo through.
